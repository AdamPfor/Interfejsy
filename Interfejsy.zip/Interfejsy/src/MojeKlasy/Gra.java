package MojeKlasy;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Arrays;

public class Gra implements IDaty, Comparable<Gra> {
    private String tytul;
    private int[] dataPremiery;

    public Gra(String tytul, int[] dataPremiery) {
        this.tytul = tytul;
        this.dataPremiery = dataPremiery;
    }

    public String getTytul() {
        return tytul;
    }

    public int[] getDataPremiery() {
        return dataPremiery;
    }

    @Override
    public String toString() {
        return "Gra{" +
                "tytul='" + tytul + '\'' +
                ", dataPremiery=" + Arrays.toString(dataPremiery) +
                '}';
    }

    @Override
    public String DzienTygodnia(int rok, int miesiac, int dzien) {
        LocalDate localDate = LocalDate.of(rok, miesiac, dzien);
        DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        return dayOfWeek.toString();
    }

    @Override
    public int DzienRoku(int rok, int miesiac, int dzien) {
        LocalDate localDate = LocalDate.of(rok, miesiac, dzien);
        return localDate.getDayOfYear();
    }

    @Override
    public int compareTo(Gra gra) {
        LocalDate thisDataPremiery = LocalDate.of(this.dataPremiery[0], this.dataPremiery[1], this.dataPremiery[2]);
        LocalDate otherDataPremiery = LocalDate.of(gra.getDataPremiery()[0], gra.getDataPremiery()[1], gra.getDataPremiery()[2]);
        return thisDataPremiery.compareTo(otherDataPremiery);
    }
}




