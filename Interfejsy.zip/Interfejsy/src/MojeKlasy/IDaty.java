package MojeKlasy;

public interface IDaty {
    String DzienTygodnia(int rok, int miesiac, int dzien);
    int DzienRoku(int rok, int miesiac, int dzien);
}


