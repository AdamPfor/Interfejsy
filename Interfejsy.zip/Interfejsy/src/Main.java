import MojeKlasy.Gra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<Gra> listaGier = new ArrayList<>();

        Gra gra1 = new Gra("Cyberpunk 2077", new int[]{2020, 12, 10});
        Gra gra2 = new Gra("The Witcher 3: Wild Hunt", new int[]{2015, 5, 19});
        Gra gra3 = new Gra("Assassin's Creed Valhalla", new int[]{2020, 11, 10});
        Gra gra4 = new Gra("Red Dead Redemption 2", new int[]{2018, 10, 26});
        Gra gra5 = new Gra("God of War", new int[]{2018, 4, 20});

        listaGier.add(gra1);
        listaGier.add(gra2);
        listaGier.add(gra3);
        listaGier.add(gra4);
        listaGier.add(gra5);

        System.out.println("Lista gier przed sortowaniem:");
        for (Gra gra : listaGier) {
            System.out.println(gra);
        }

        Collections.sort(listaGier);

        System.out.println("Lista gier po sortowaniu:");
        for (Gra gra : listaGier) {
            System.out.println(gra);
        }
    }
}
